# The Academy デザイン素材 一式（LP＋コースを探す）

HTML・CSSで作ったデザインを、すべて単体の画像として書き出したものです。3種類あります。

1. **セクション全体**（sections-lp / sections-courses）：各セクションを背景ごと1枚にしたもの。デザインカンプとして使えます。
2. **ビジュアル**（各フォルダの visual-*、community-visual、visual-full）：各セクションの絵の部分を、はみ出したキャラクター・冊子・装飾まで含めて丸ごと。
3. **部品**：カード・ボタン・画面イメージなどの単体。

## 形式
- PNG（@2x）：2倍解像度・背景透過（セクション全体は背景つき）。PC表示（幅1440px）の見た目。
- SVG：文字はアウトライン化済み、写真は埋め込み済み。拡大しても崩れません。文言を直すときはHTMLの原稿から書き出し直してください。
- スマホのトーク画面は、外枠が切れないよう周りに12px、ビジュアルは4pxの余白をとっています。

## Heroの背景（調整済み）
- 00-hero/hero-background-<幅>@2x.png：写真＋白のフェード（サイトで見えているまま、文字なし）
- 00-hero/hero-fade-overlay-<幅>@2x.png：白のフェードだけ（透過）
- 00-hero/hero-photo-original.webp：元の写真

## 一覧（各ファイルに .svg と @2x.png の2種類）
| セクション | 種類 | ファイル（拡張子なし） | サイズ(px) |
|---|---|---|---|
| 共通 | 部品 | 00-common/topbar | 1440×36 |
| 共通 | 部品 | 00-common/header | 1440×77 |
| 共通 | 部品 | 00-common/logo-blue | 184×32 |
| 共通 | 部品 | 00-common/footer | 1440×490 |
| 共通 | 部品 | 00-common/logo-white | 200×42 |
| 共通 | 部品 | 00-common/sns-icons | 326×32 |
| 共通 | 部品 | 00-common/section-heading | 1180×162 |
| 共通 | 部品 | 00-common/link-more | 149×40 |
| Hero | 部品 | 00-hero/hero-copy | 640×531 |
| Hero | 部品 | 00-hero/hero-buttons | 640×54 |
| Hero | 部品 | 00-hero/hero-stats | 438×85 |
| 01 START HERE | 部品 | 01-start-here/goal-card-1 | 280×240 |
| 01 START HERE | 部品 | 01-start-here/goal-card-2 | 280×240 |
| 01 START HERE | 部品 | 01-start-here/goal-card-3 | 280×240 |
| 01 START HERE | 部品 | 01-start-here/goal-card-4 | 280×240 |
| 02 WHY | 部品 | 02-why/point-1-course | 372×566 |
| 02 WHY | 部品 | 02-why/point-2-portfolio | 372×566 |
| 02 WHY | 部品 | 02-why/point-3-community | 372×566 |
| 03 人気のコース | 部品 | 03-popular/course-card-sns-marketing | 280×494 |
| 03 人気のコース | 部品 | 03-popular/course-card-ai-efficiency | 280×494 |
| 03 人気のコース | 部品 | 03-popular/course-card-toeic-700 | 280×494 |
| 03 人気のコース | 部品 | 03-popular/line-coupon-card | 280×494 |
| 04 ポートフォリオ | 部品 | 04-portfolio/portfolio-card-1 | 375×450 |
| 04 ポートフォリオ | 部品 | 04-portfolio/portfolio-card-2 | 375×450 |
| 04 ポートフォリオ | 部品 | 04-portfolio/portfolio-card-3 | 375×450 |
| 05 コミュニティ | 部品 | 05-community/talk-screen | 344×363 |
| 05 コミュニティ | ビジュアル（はみ出す装飾も含む） | 05-community/community-visual | 617×363 |
| 06 受講までの流れ | 部品 | 06-flow/step-bar | 1180×75 |
| 06 受講までの流れ | 部品 | 06-flow/step-1 | 282×291 |
| 06 受講までの流れ | 部品 | 06-flow/step-2 | 282×291 |
| 06 受講までの流れ | 部品 | 06-flow/step-3 | 282×291 |
| 06 受講までの流れ | 部品 | 06-flow/step-4 | 282×291 |
| 07 NEXT STEP | 部品 | 07-next-step/call-screen | 440×278 |
| 07 NEXT STEP | ビジュアル（はみ出す装飾も含む） | 07-next-step/visual-full | 536×462 |
| 08 学びのヒント | 部品 | 08-journal/article-card-1 | 380×423 |
| 08 学びのヒント | 部品 | 08-journal/article-card-2 | 380×423 |
| 08 学びのヒント | 部品 | 08-journal/article-card-3 | 380×423 |
| 08 学びのヒント | 部品 | 08-journal/resources-band | 1180×68 |
| 09 公式LINE | 部品 | 09-line/talk-screen | 324×417 |
| 09 公式LINE | ビジュアル（はみ出す装飾も含む） | 09-line/visual-full | 507×473 |
| 09 公式LINE | 部品 | 09-line/benefits | 609×193 |
| 09 公式LINE | 部品 | 09-line/button-add-friend | 300×56 |
| コースを探す | 部品 | courses/page-head | 1440×327 |
| コースを探す | 部品 | courses/featured-1-slack | 578×739 |
| コースを探す | 部品 | courses/featured-2-toeic | 578×739 |
| コースを探す | 部品 | courses/filter-bar | 1180×100 |
| コースを探す | 部品 | courses/line-band | 1180×127 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/00a-topbar | 1440×36 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/00b-header | 1440×77 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/00-hero | 1440×720 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/01-start-here | 1440×674 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/02-why | 1440×1000 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/03-popular | 1440×940 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/04-portfolio | 1440×884 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/05-community | 1440×653 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/06-flow | 1440×959 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/07-next-step | 1440×868 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/08-journal | 1440×945 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/09-line | 1440×808 |
| LP：セクション全体 | セクション全体（背景つき） | sections-lp/10-footer | 1440×490 |
| コースを探す：セクション全体 | セクション全体（背景つき） | sections-courses/1-page-head | 1440×327 |
| コースを探す：セクション全体 | セクション全体（背景つき） | sections-courses/2-featured | 1440×1118 |
| コースを探す：セクション全体 | セクション全体（背景つき） | sections-courses/3-course-list | 1440×2007 |
| コースを探す：セクション全体 | セクション全体（背景つき） | sections-courses/4-line-band | 1440×207 |
| コースを探す：セクション全体 | セクション全体（背景つき） | sections-courses/5-next-step | 1440×846 |
| 01 START HERE | ビジュアル（はみ出す装飾も含む） | 01-start-here/visual-illust-1 | 120×120 |
| 01 START HERE | ビジュアル（はみ出す装飾も含む） | 01-start-here/visual-illust-2 | 120×120 |
| 01 START HERE | ビジュアル（はみ出す装飾も含む） | 01-start-here/visual-illust-3 | 120×120 |
| 01 START HERE | ビジュアル（はみ出す装飾も含む） | 01-start-here/visual-illust-4 | 120×120 |
| 02 WHY | ビジュアル（はみ出す装飾も含む） | 02-why/visual-tile-1-course | 380×384 |
| 02 WHY | ビジュアル（はみ出す装飾も含む） | 02-why/visual-tile-2-portfolio | 380×384 |
| 02 WHY | ビジュアル（はみ出す装飾も含む） | 02-why/visual-tile-3-community | 380×384 |
| 03 人気のコース | ビジュアル（はみ出す装飾も含む） | 03-popular/visual-thumb-sns-marketing | 288×184 |
| 03 人気のコース | ビジュアル（はみ出す装飾も含む） | 03-popular/visual-thumb-ai-efficiency | 288×184 |
| 03 人気のコース | ビジュアル（はみ出す装飾も含む） | 03-popular/visual-thumb-toeic-700 | 288×184 |
| 04 ポートフォリオ | ビジュアル（はみ出す装飾も含む） | 04-portfolio/visual-screen-1 | 383×308 |
| 04 ポートフォリオ | ビジュアル（はみ出す装飾も含む） | 04-portfolio/visual-screen-2 | 383×308 |
| 04 ポートフォリオ | ビジュアル（はみ出す装飾も含む） | 04-portfolio/visual-screen-3 | 383×308 |
| 05 コミュニティ | ビジュアル（はみ出す装飾も含む） | 05-community/visual-crowd | 307×134 |
| 06 受講までの流れ | ビジュアル（はみ出す装飾も含む） | 06-flow/visual-step-1 | 290×238 |
| 06 受講までの流れ | ビジュアル（はみ出す装飾も含む） | 06-flow/visual-step-2 | 290×238 |
| 06 受講までの流れ | ビジュアル（はみ出す装飾も含む） | 06-flow/visual-step-3 | 290×238 |
| 06 受講までの流れ | ビジュアル（はみ出す装飾も含む） | 06-flow/visual-step-4 | 290×238 |
| コースを探す | ビジュアル（はみ出す装飾も含む） | courses/visual-featured-1-slack | 586×369 |
| コースを探す | ビジュアル（はみ出す装飾も含む） | courses/visual-featured-2-toeic | 586×369 |
| コースを探す：コースカード | 部品 | courses/course-cards/sns-marketing | 280×495 |
| コースを探す：コースカード | 部品 | courses/course-cards/ai-efficiency | 280×495 |
| コースを探す：コースカード | 部品 | courses/course-cards/toeic-700 | 280×495 |
| コースを探す：コースカード | 部品 | courses/course-cards/event-design | 280×495 |
| コースを探す：コースカード | 部品 | courses/course-cards/marketing-basic | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/instagram | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/automation | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/chatgpt-basic | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/line-official | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/business-english | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/project-management | 280×461 |
| コースを探す：コースカード | 部品 | courses/course-cards/canva-basic | 280×461 |
| Hero | 背景（調整済み） | 00-hero/hero-background-1440@2x.png | 2880×1440 |
| Hero | 背景（調整済み） | 00-hero/hero-background-1920@2x.png | 3840×1440 |
| Hero | 背景（調整済み） | 00-hero/hero-background-390@2x.png | 780×1866 |
| Hero | 背景（調整済み） | 00-hero/hero-fade-overlay-1440@2x.png | 2880×1440 |
| Hero | 背景（調整済み） | 00-hero/hero-fade-overlay-1920@2x.png | 3840×1440 |
| Hero | 背景（調整済み） | 00-hero/hero-fade-overlay-390@2x.png | 780×1866 |
| Hero | 背景（調整済み） | 00-hero/hero-photo-original.webp | 1672×941 |
