# The Academy デザイン部品 一式（LP＋コースを探す）

LPデザイン（lp/lp-design.html）とコースを探す（lp/courses.html）で、HTML・CSSで組んだデザイン部品を単体で書き出したものです。

- **PNG**：背景透過・2倍解像度（@2x）。PC表示（幅1440px）の見た目で書き出しています。
- **SVG**：文字はアウトライン化済み（フォントがなくても形が崩れません）。写真は埋め込み済みです。文字の打ち直しが必要な場合は、HTMLの原稿（lp-design.html / courses.html）から取ってください。
- スマホの枠（トーク画面）は、外側の線が切れないように周りに12pxの余白をとっています。

## Heroの背景（調整済み）
- hero-background-<幅>@2x.png：写真に白のフェード（左端62%→中央80%→右側0%、下からも白）を重ねた、サイトで見えているままの背景（文字なし）。幅1920／1440／390（スマホ）の3種。
- hero-fade-overlay-<幅>@2x.png：白のフェードだけ（透過PNG）。写真の上に重ねて使えます。
- hero-photo-original.webp：元の写真（1672×941、調整なし）。

## 一覧
| セクション | ファイル（拡張子なし） | サイズ(px) | 形式 |
|---|---|---|---|
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/topbar | 1440×36 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/header | 1440×77 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/logo-blue | 184×32 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/footer | 1440×490 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/logo-white | 200×42 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/sns-icons | 326×32 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/section-heading | 1180×162 | PNG(@2x・透過) / SVG |
| 共通（ヘッダー・フッター・ロゴ・見出しの型） | 00-common/link-more | 149×40 | PNG(@2x・透過) / SVG |
| Hero | 00-hero/hero-copy | 640×531 | PNG(@2x・透過) / SVG |
| Hero | 00-hero/hero-buttons | 640×54 | PNG(@2x・透過) / SVG |
| Hero | 00-hero/hero-stats | 438×85 | PNG(@2x・透過) / SVG |
| 01 START HERE | 01-start-here/goal-card-1 | 280×240 | PNG(@2x・透過) / SVG |
| 01 START HERE | 01-start-here/goal-card-2 | 280×240 | PNG(@2x・透過) / SVG |
| 01 START HERE | 01-start-here/goal-card-3 | 280×240 | PNG(@2x・透過) / SVG |
| 01 START HERE | 01-start-here/goal-card-4 | 280×240 | PNG(@2x・透過) / SVG |
| 02 WHY | 02-why/point-1-course | 372×566 | PNG(@2x・透過) / SVG |
| 02 WHY | 02-why/point-2-portfolio | 372×566 | PNG(@2x・透過) / SVG |
| 02 WHY | 02-why/point-3-community | 372×566 | PNG(@2x・透過) / SVG |
| 03 人気のコース | 03-popular/course-card-sns-marketing | 280×494 | PNG(@2x・透過) / SVG |
| 03 人気のコース | 03-popular/course-card-ai-efficiency | 280×494 | PNG(@2x・透過) / SVG |
| 03 人気のコース | 03-popular/course-card-toeic-700 | 280×494 | PNG(@2x・透過) / SVG |
| 03 人気のコース | 03-popular/line-coupon-card | 280×494 | PNG(@2x・透過) / SVG |
| 04 ポートフォリオ | 04-portfolio/portfolio-card-1 | 375×450 | PNG(@2x・透過) / SVG |
| 04 ポートフォリオ | 04-portfolio/portfolio-card-2 | 375×450 | PNG(@2x・透過) / SVG |
| 04 ポートフォリオ | 04-portfolio/portfolio-card-3 | 375×450 | PNG(@2x・透過) / SVG |
| 05 コミュニティ | 05-community/talk-screen | 344×363 | PNG(@2x・透過) / SVG |
| 05 コミュニティ | 05-community/community-visual | 554×347 | PNG(@2x・透過) / SVG |
| 06 受講までの流れ | 06-flow/step-bar | 1180×75 | PNG(@2x・透過) / SVG |
| 06 受講までの流れ | 06-flow/step-1 | 282×291 | PNG(@2x・透過) / SVG |
| 06 受講までの流れ | 06-flow/step-2 | 282×291 | PNG(@2x・透過) / SVG |
| 06 受講までの流れ | 06-flow/step-3 | 282×291 | PNG(@2x・透過) / SVG |
| 06 受講までの流れ | 06-flow/step-4 | 282×291 | PNG(@2x・透過) / SVG |
| 07 NEXT STEP | 07-next-step/call-screen | 440×278 | PNG(@2x・透過) / SVG |
| 07 NEXT STEP | 07-next-step/visual-full | 528×414 | PNG(@2x・透過) / SVG |
| 08 学びのヒント | 08-journal/article-card-1 | 380×423 | PNG(@2x・透過) / SVG |
| 08 学びのヒント | 08-journal/article-card-2 | 380×423 | PNG(@2x・透過) / SVG |
| 08 学びのヒント | 08-journal/article-card-3 | 380×423 | PNG(@2x・透過) / SVG |
| 08 学びのヒント | 08-journal/resources-band | 1180×68 | PNG(@2x・透過) / SVG |
| 09 公式LINE | 09-line/talk-screen | 324×417 | PNG(@2x・透過) / SVG |
| 09 公式LINE | 09-line/visual-full | 499×465 | PNG(@2x・透過) / SVG |
| 09 公式LINE | 09-line/benefits | 609×193 | PNG(@2x・透過) / SVG |
| 09 公式LINE | 09-line/button-add-friend | 300×56 | PNG(@2x・透過) / SVG |
| コースを探す | courses/page-head | 1440×327 | PNG(@2x・透過) / SVG |
| コースを探す | courses/featured-1-slack | 578×739 | PNG(@2x・透過) / SVG |
| コースを探す | courses/featured-2-toeic | 578×739 | PNG(@2x・透過) / SVG |
| コースを探す | courses/filter-bar | 1180×100 | PNG(@2x・透過) / SVG |
| コースを探す | courses/line-band | 1180×127 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/sns-marketing | 280×495 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/ai-efficiency | 280×495 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/toeic-700 | 280×495 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/event-design | 280×495 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/marketing-basic | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/instagram | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/automation | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/chatgpt-basic | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/line-official | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/business-english | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/project-management | 280×461 | PNG(@2x・透過) / SVG |
| コースを探す：コースカード12枚 | courses/course-cards/canva-basic | 280×461 | PNG(@2x・透過) / SVG |
| Hero（背景） | 00-hero/hero-background-1440@2x.png | 2880×1440 | PNG |
| Hero（背景） | 00-hero/hero-background-1920@2x.png | 3840×1440 | PNG |
| Hero（背景） | 00-hero/hero-background-390@2x.png | 780×1866 | PNG |
| Hero（背景） | 00-hero/hero-fade-overlay-1440@2x.png | 2880×1440 | PNG |
| Hero（背景） | 00-hero/hero-fade-overlay-1920@2x.png | 3840×1440 | PNG |
| Hero（背景） | 00-hero/hero-fade-overlay-390@2x.png | 780×1866 | PNG |
| Hero（背景） | 00-hero/hero-photo-original.webp | 1672×941 | WEBP |
