# コースを探す「特集」素材データ

| フォルダ | ファイル | 内容 |
|---|---|---|
| original/ | feat-slack_original.png / feat-toeic_original.jpg | 支給いただいた元画像（1920×1080／1200×630） |
| web/ | feat-slack.webp・.png | サイト用。特集1（Slack×GAS）。左右の余白を切り詰めたもの（1362×1080） |
|  | feat-toeic.webp・.png | サイト用。特集2（TOEIC L&R 700点突破）（1200×630） |
| png/ | section-1440@2x.png / section-390@2x.png | 特集セクション全体（PC／スマホ、2倍解像度） |
|  | card-slack@2x.png / card-toeic@2x.png | 特集カード単体（PC、2倍解像度） |

## カード内の文言
- 特集1：Slack×GAS タスク管理システム／プロジェクト進行のズレやムダを、減らす。／要点：¥0 月額サービス手数料・Slack内で完結・FAQ・ガントをまとめて確認・仕様書付きで簡単設定
- 特集2：TOEIC L&R 700点突破プログラム／苦手を得意に変える、3か月で自信の持てる英語力を。／要点：3か月・週2回・全24回・1対1マンツーマン

サイトでの配置場所：lp/assets/courses/feat-slack.webp・feat-toeic.webp（同じ名前で差し替え可）
